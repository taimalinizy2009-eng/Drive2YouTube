package com.drive2youtube.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
        }

        val title = TextView(this).apply {
            text = "Drive2YouTube"
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        val status = TextView(this).apply {
            text = "\nنسخة تجريبية أولية\n\nهذه النسخة لا تتصل بعد بـ Google Drive أو YouTube، ولا ترفع الفيديوهات.\n\nسيتم إضافة تسجيل الدخول والصلاحيات والرفع بعد إعداد Google Cloud واختبار واجهات Google الرسمية."
            textSize = 17f
            gravity = Gravity.CENTER
        }
        layout.addView(title)
        layout.addView(status)
        setContentView(layout)
    }
}
